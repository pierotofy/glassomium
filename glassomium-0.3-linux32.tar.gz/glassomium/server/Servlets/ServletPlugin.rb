class ServletPlugin
	def get_servlet_handlers
	   raise 'this method should be overriden (get_servlet_handlers)'
	end
end